<div class="row">
    <div class="col-lg-12 grid-margin">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table style="width:100%">
                        <tr>
                            <td colspan="2" class="card-title" style="text-align: left; font-weight:bold">Disbursement Payment List:
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <hr>
                            </td>
                        </tr>
                    </table>
                    <form method="GET" id="disbursementClaimSearchForm">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th> # </th>
                                    <th> Claim ID </th>
                                    <th> Benificiary Name </th>
                                    <th> Subsidy Scheme </th>
                                    <th style="text-align: right;"> Allocated Amount </th>
                                    <th style="text-align: right;"> Paid Amount </th>
                                    <!-- <th> Status </th> -->
                                    <th style="text-align:right;"> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>