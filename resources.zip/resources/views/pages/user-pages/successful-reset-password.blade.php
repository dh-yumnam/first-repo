         <div class="table-responsive">
             <form class="pt-5">

                 <div class="form-group text-center">
                     Please <a href="{{ url('/') }}"><span style="color: red;">click here</span></a> to login with new password!
                 </div>
                 <div class="mt-3 text-center">
                 </div>
             </form>
         </div>