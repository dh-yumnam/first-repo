<div id="contain">
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <div style="text-align: center">
                        <h1 style="color: red;">Access Denied !</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>