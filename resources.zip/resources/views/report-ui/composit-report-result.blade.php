<div class="row">
    <div class="col-lg-12 grid-margin">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <div class="row invoice row-printable" id="export">
                        <div class="col-md-12">
                            <!-- col-lg-12 start here -->
                            <div class="panel panel-default plain" id="dash_0">
                                <!-- Start .panel -->
                                <div class="panel-body p30">
                                    <div class="row">
                                        <!-- Start .row -->
                                        <div class="col-lg-4">
                                            <!-- col-lg-6 start here -->
                                            <div class="invoice-logo"><img width="60" src="{{ url('assets/images/favicon.ico') }}" alt="NEDFi logo"></div>
                                        </div>
                                        <div class="col-lg-3">
                                            <!-- col-lg-6 start here -->
                                            <!-- <div class="invoice-tittle">
                                                <h4><b>Claim Received Report</b></h4>
                                            </div> -->
                                        </div>
                                        <!-- col-lg-6 end here -->
                                        <div class="col-lg-5">
                                            <!-- col-lg-6 start here -->
                                            <div class="invoice-from">
                                                <ul class="list-unstyled text-right" style="font-size:smaller">
                                                    <li>
                                                        <h4><b><span>Composit Report</span></b></h4>
                                                    </li>
                                                    <li>
                                                        <b>North Eastern Development Finance Corporation Ltd</b>
                                                    </li>
                                                    <li>
                                                        <b>नार्थ ईस्टर्न डेवलपमेंट फाइनेंस कारपोरेशन लिमिटिड</b>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <br>
                                        <br>
                                        <!-- col-lg-6 end here -->
                                        <div class="col-lg-12">
                                            <!-- col-lg-12 start here -->
                                            <div class="invoice-details mt25">
                                                <div class="well">
                                                    <ul class="list-unstyled mb0">
                                                        <li><strong>Scheme</strong>@if(!empty($scheme_name)) {{$scheme_name}} @else - - - - @endif</li>
                                                        <li><strong>SLC Date Duration:</strong>@if(!empty($from)) {{date('d M Y', strtotime( $from))}} - {{date('d M Y', strtotime( $to))}} @else - - - - @endif</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="invoice-items">
                                                <div class="table-responsive" style="overflow: hidden; outline: none;" tabindex="0">
                                                    <table id="dataTable" class="table1 table-bordered" cellpadding="5" style="font-size:8pt;" width="100%">
                                                        <thead>
                                                            <tr>
                                                                <th width="4%"> # </th>
                                                                <th width="9%"> Unit Name </th>
                                                                <th width="8%"> Address </th>
                                                                <th width="8%"> Partner/Propitor </th>
                                                                <th width="5%"> Status </th>
                                                                <th width="6%"> Subsidy Reg No. </th>
                                                                <th width="6%"> App Recv </th>
                                                                <th width="6%"> SLC Date </th>
                                                                <th colspan="2" width="12%" class="text-center"> Prduction </th>
                                                                <th colspan="2" width="11%" class="text-center"> Claim Period </th>
                                                                <th colspan="2" width="11%" class="text-center"> Approved amount </th>
                                                                <th colspan="3" width="17%" class="text-center">Disbursement Details </th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @php
                                                            $total =0;
                                                            $count =0;
                                                            $sub_total =0;
                                                            $length=0;
                                                            $state ='';
                                                            @endphp
                                                            @php $length=count($smsCompositReport); @endphp
                                                            <tr>
                                                                <th colspan="8"></th>
                                                                <th class="text-left">Date</th>
                                                                <th class="text-right">Capacity</th>
                                                                <th class="text-left">From</th>
                                                                <th class="text-left">To</th>
                                                                <th class="text-right">Material</th>
                                                                <th class="text-right">Goods</th>
                                                                <th class="text-left">Chq. No.</th>
                                                                <th class="text-left">Date </th>
                                                                <th class="text-right">Amount</th>
                                                            </tr>
                                                            @forelse ($smsCompositReport as $smsCompositReport)
                                                            @if($smsCompositReport->State_Name!=$state)
                                                            @if ($loop->iteration>1)
                                                            <tr>
                                                                <th colspan="15" class="text-right">Sub Total Rs.:</th>
                                                                <th colspan="2" class="text-right">{{number_format($sub_total,3)}}</th>
                                                            </tr>
                                                            @endif
                                                            @php $state=$smsCompositReport->State_Name; @endphp
                                                            @php $count=0; @endphp
                                                            @php $sub_total=0; @endphp
                                                            <tr>
                                                                <td colspan="17" style="background: #CCC; font-weight:bold;">{{$smsCompositReport->State_Name}}</td>
                                                            </tr>
                                                            @endif
                                                            @php $count=$count+1; @endphp
                                                            @php $sub_total=$sub_total+$smsCompositReport->Disbursement_Amt; @endphp
                                                            <tr>
                                                                <td> {{$count}}</td>
                                                                <td> {{$smsCompositReport->Benificiary_Name}}</td>
                                                                <td> {{$smsCompositReport->Address1}} {{$smsCompositReport->Address2}} </td>
                                                                <td> N/A </td>
                                                                <td> @if($smsCompositReport->Unit_Status==1)New @else Expansion @endif </td>
                                                                <td> {{$smsCompositReport->Subsidy_Regn_No}} </td>
                                                                <td> @if(!empty($smsCompositReport->Received_Date)) {{date('d M Y', strtotime($smsCompositReport->Received_Date))}} @else - - - - @endif </td>
                                                                <td> @if(!empty($smsCompositReport->Slc_Date)) {{date('d M Y', strtotime($smsCompositReport->Slc_Date))}} @else - - - - @endif</td>
                                                                <td> @if(!empty($smsCompositReport->Production_Date)) {{date('d M Y', strtotime($smsCompositReport->Production_Date))}} @else - - - - @endif</td>
                                                                <td> {{$smsCompositReport->Production_Capacity}}</td>
                                                                <td> @if(!empty($smsCompositReport->Claim_From_Date)) {{date('d M Y', strtotime($smsCompositReport->Claim_From_Date))}} @else - - - - @endif</td>
                                                                <td> @if(!empty($smsCompositReport->Claim_To_Date)) {{date('d M Y', strtotime($smsCompositReport->Claim_To_Date))}} @else - - - - @endif</td>
                                                                <td> {{$smsCompositReport->Material_Name}} </td>
                                                                <td> {{$smsCompositReport->Goods_Name }}</td>
                                                                <td> {{$smsCompositReport->Instrument_No}}</td>
                                                                <td> {{date('d M Y', strtotime($smsCompositReport->Instrument_Date))}}</td>
                                                                <td align="right"> {{number_format($smsCompositReport->Disbursement_Amt,3)}} </td>
                                                                @php $total=$total+$smsCompositReport->Disbursement_Amt; @endphp
                                                            </tr>
                                                            @if ($length==$loop->iteration)
                                                            <tr>
                                                                <th colspan="15" class="text-right">Sub Total Rs.:</th>
                                                                <th colspan="2" class="text-right">{{number_format($sub_total,3)}}</th>
                                                            </tr>
                                                            @endif
                                                            @empty
                                                            <tr>
                                                                <td colspan="17" align="center" width="100%">No Records Found !!</td>
                                                            </tr>
                                                            @endforelse
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th colspan="15" class="text-right">Grand Total Rs.:</th>
                                                                <th colspan="2" class="text-right">{{number_format($total,3)}}</th>
                                                            </tr>
                                                            <!-- <tr>
                                                                <th colspan="6" class="text-right">20% VAT:</th>
                                                                <th class="text-center">$47.40 USD</th>
                                                            </tr> -->
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="invoice-footer mt25">
                                                <p class="text-center">Generated on {{date('d M Y', strtotime( $current))}}</p>
                                            </div>
                                        </div>
                                        <!-- col-lg-12 end here -->
                                    </div>
                                    <!-- End .row -->
                                </div>
                            </div>
                            <!-- End .panel -->
                        </div>
                        <!-- col-lg-12 end here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>