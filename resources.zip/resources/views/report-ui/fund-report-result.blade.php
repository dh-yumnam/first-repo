<div class="row">
    <div class="col-lg-12 grid-margin">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <div class="row invoice row-printable" id="export">
                        <div class="col-md-12">
                            <!-- col-lg-12 start here -->
                            <div class="panel panel-default plain" id="dash_0">
                                <!-- Start .panel -->
                                <div class="panel-body p30">
                                    <div class="row">
                                        <!-- Start .row -->
                                        <div class="col-lg-4">
                                            <!-- col-lg-6 start here -->
                                            <div class="invoice-logo"><img width="60" src="{{ url('assets/images/favicon.ico') }}" alt="NEDFi logo"></div>
                                        </div>
                                        <div class="col-lg-4">
                                            <!-- col-lg-6 start here -->
                                            <div class="invoice-tittle">
                                                <!-- <h4><b>Fund Received Report</b></h4> -->
                                            </div>
                                        </div>
                                        <!-- col-lg-6 end here -->
                                        <div class="col-lg-4">
                                            <!-- col-lg-6 start here -->
                                            <div class="invoice-from">
                                                <ul class="list-unstyled text-right" style="font-size:smaller">
                                                    <li>
                                                        <h4><b><span>Fund Received Report</span></b></h4>
                                                    </li>
                                                    <li>
                                                        <b>North Eastern Development Finance Corporation Ltd</b>
                                                    </li>
                                                    <li>
                                                        <b>नार्थ ईस्टर्न डेवलपमेंट फाइनेंस कारपोरेशन लिमिटिड</b>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <br>
                                        <br>
                                        <hr>
                                        <!-- col-lg-6 end here -->
                                        <div class="col-lg-12">
                                            <!-- col-lg-12 start here -->
                                            <div class="invoice-details mt25">
                                                <div class="well">
                                                    <ul class="list-unstyled mb0">
                                                        <li><strong>Scheme</strong> Transport</li>
                                                        <li><strong>Registration Date Range:</strong>@if(!empty($from)) {{date('d M Y', strtotime( $from))}} - {{date('d M Y', strtotime( $to))}} @else - - - - @endif</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="invoice-items">
                                                <div class="table-responsive" style="overflow: hidden; outline: none;" tabindex="0">
                                                    <table id="dataTable" class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th> # </th>
                                                                <th> Sanction Letter </th>
                                                                <th> Sanction Date </th>
                                                                <th> Scheme </th>
                                                                <th class="text-right"> Sanction Amount </th>
                                                                <th class="text-right"> Balance Amount </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @php
                                                            $totalSanc =0;
                                                            $totalBal =0;
                                                            @endphp
                                                            @forelse ($subsidyFund as $subsidyFund)
                                                            <tr>
                                                                <td> {{$loop->iteration}} </td>
                                                                <td> {{$subsidyFund->Sanction_Letter}} </td>
                                                                <td> {{ date('d-M-Y', strtotime($subsidyFund->Sanction_Date))}}</td>
                                                                <td> {{$subsidyFund->Scheme_Name}}</td>
                                                                <td class="text-right"> {{number_format($subsidyFund->Sanction_Amt,3)}} </td>
                                                                <td class="text-right"> {{number_format($subsidyFund->Fund_Bal,3)}} </td>
                                                                @php $totalSanc=$totalSanc+$subsidyFund->Sanction_Amt; @endphp
                                                                @php $totalBal=$totalBal+$subsidyFund->Fund_Bal; @endphp
                                                            </tr>
                                                            @empty
                                                            <tr>
                                                                <td colspan="6" align="center">No Records Found !!</td>
                                                            </tr>
                                                            @endforelse
                                                        </tbody>

                                                        <tfoot>
                                                            <tr>
                                                                <th colspan="4" class="text-right">Total Rs.:</th>
                                                                <th class="text-right">{{number_format($totalSanc,3)}}</th>
                                                                <th class="text-right">{{number_format($totalBal,3)}}</th>
                                                            </tr>
                                                            <!-- <tr>
                                                                <th colspan="6" class="text-right">20% VAT:</th>
                                                                <th class="text-center">$47.40 USD</th>
                                                            </tr> -->
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="invoice-footer mt25">
                                                <p class="text-center">Generated on {{date('d M Y', strtotime( $current))}}</p>
                                            </div>
                                        </div>
                                        <!-- col-lg-12 end here -->
                                    </div>
                                    <!-- End .row -->
                                </div>
                            </div>
                            <!-- End .panel -->
                        </div>
                        <!-- col-lg-12 end here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>